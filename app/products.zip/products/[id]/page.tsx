import Image from "next/image";
import Link from "next/link";
import {
  ArrowLeft,
  CheckCircle,
  Download,
  Star,
  Truck,
  Shield,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/header";
import Footer from "@/components/footer";

// This would normally come from a database
const getProductData = (id: string) => {
  const products = {
    "metal-fire-door-1": {
      id: "metal-fire-door-1",
      title: "Metal Fire Door",
      description:
        "Galvanized/stainless steel fire resistant doors with 60-120 minutes fire rating",
      longDescription:
        "Metal fire doors are fabricated with two layered Galvanized/stainless steel sheet sandwiching with proprietary fire resistant insulation materials Honeycomb/Rock Wool in between with sheet thickness of outer frame up to 1.6mm and shutter up to 1.2mm as per standard requirement. Doors come with 60 minutes to 120 minutes fire rating. Door come single and double rebate as per the client requirements. Steel reinforcements are provided for structural stability and integrity. All doors are pre-engineered at the plant to receive prior selected hardware. The doors are delivered to customers along with hardware of approved or select brands. Fire Rated Door finish available with durable and corrosion resistance powder coating.",
      imageSrc: "/Images/product2.png",
      additionalImages: [],
      price: 45000,
      rating: 4.8,
      reviews: 24,
      features: [
        "60-120 minutes fire rating",
        "Galvanized/stainless steel construction",
        "Honeycomb/Rock Wool insulation",
        "Sheet thickness: frame up to 1.6mm, shutter up to 1.2mm",
        "Single and double rebate options",
        "Pre-engineered for hardware installation",
        "Durable powder coating finish",
      ],
      specifications: {
        Material: "Galvanized/stainless steel",
        "Frame Thickness": "Up to 1.6mm",
        "Shutter Thickness": "Up to 1.2mm",
        "Fire Rating": "60-120 minutes",
        Insulation: "Honeycomb/Rock Wool",
        Finish: "Powder coated (customizable color)",
        "Rebate Type": "Single or double rebate",
        Certification: "IS 3614, BS 476 Part 22",
      },
      category: "fire-door",
      badge: "Fire Resistant",
      badgeColor: "bg-red-500",
      inStock: true,
      deliveryTime: "3-4 weeks",
      warranty: "5 years",
    },
    "Double-layered-doors": {
      id: "Double-layered-doors",
      title: "Double-layered-doors",
      description: "Fire rated doors with 120 minutes fire resistance rating",
      longDescription:
        "Double-layered doors with 120 minutes fire resistance rating",
      imageSrc: "/Images/product4.png",
      additionalImages: [],
      price: 52000,
      rating: 4.9,
      reviews: 18,
      features: ["120 minutes fire resistance rating"],
      specifications: {
        "Frame Material": "Hard wood/teak wood",
        "Frame Dimensions": "145mm x 70mm",
        "Shutter Thickness": "55mm",
        "Fire Rating": "120 minutes",
        Construction: "Calcium silicate boards with fire resistance insulation",
        Facing: "3mm commercial ply on both sides",
        Seal: "Heat activated intumescent fire seal strip (10mm x 4mm)",
        Certification: "BS: 476 Part-22 & IS: 3614 Part-II",
      },
      category: "fire-door",
      badge: "Fire Resistant",
      badgeColor: "bg-red-500",
      inStock: true,
      deliveryTime: "4-5 weeks",
      warranty: "5 years",
    },
    "panic-bar-1": {
      id: "panic-bar-1",
      title: "Panic Bar and External Trim",
      description:
        "Single and double point panic bars for emergency exit doors",
      longDescription:
        "We deal in all kinds of panic bars which come in single point and double point to meet the requirement of door size. Push bar comes with one point press type locking. Panic bar latch set consisting of main panic latch component, end component, striker kit, end caps with silver finishing. It is corrosion resistant and as per need to meet NBC requirement for exit door evacuation. We also deal in different brands of panic bar like: DORMA, GEZE, YALE, ASSA-ABLOY, BRITON, HAFELE.",
      imageSrc: "/Images/panic_bars.jpeg",
      // additionalImages: [],
      price: 12000,
      rating: 4.7,
      reviews: 15,
      features: [
        "Single and double point locking options",
        "Corrosion resistant construction",
        "NBC compliant for exit door evacuation",
        "Press type locking mechanism",
        "Silver finish with quality components",
        "Compatible with various door types",
      ],
      specifications: {
        Type: "Single/Double point panic bar",
        Material: "Stainless steel with silver finish",
        Components: "Main panic latch, end component, striker kit, end caps",
        Compliance: "NBC requirements for exit door evacuation",
        Compatibility: "Compatible with fire doors and emergency exits",
        "Brands Available": "DORMA, GEZE, YALE, ASSA-ABLOY, BRITON, HAFELE",
      },
      category: "hardware",
      badge: "Safety Hardware",
      badgeColor: "bg-blue-500",
      inStock: true,
      deliveryTime: "1-2 weeks",
      warranty: "3 years",
    },
    "door-closer-1": {
      id: "door-closer-1",
      title: "Door Closer",
      description:
        "Fire rated door closers for automatic door closing in emergency situations",
      longDescription:
        "Door closer is used for the movement of doors to settle down the door again to that place from where it has been moved. It is used on fire rated doors so that doors can be closed every time to eradicate the emergency situation of fire case which help doors to resist fire to enter that another place. We are involved in offering our clients a wide array of Fire Rated Door Closers that are manufactured using high grade and durable ingredients. The range of fire rated door closers includes various types such as concealed type and hold open type.",
      imageSrc: "/Images/Door-Closer.png",
      additionalImages: [],
      price: 5000,
      rating: 4.5,
      reviews: 22,
      features: [
        "Fire rated for emergency situations",
        "Automatic door closing mechanism",
        "Concealed and hold open types available",
        "High-grade durable construction",
        "Adjustable closing speed",
        "Compatible with various door weights",
      ],
      specifications: {
        Type: "Concealed/Hold open",
        Material: "High-grade metal",
        "Fire Rating": "Up to 120 minutes",
        "Door Weight": "Various capacities available",
        "Closing Speed": "Adjustable",
        Installation: "Surface mounted or concealed",
        Finish: "Multiple finishes available",
      },
      category: "hardware",
      badge: "Safety Hardware",
      badgeColor: "bg-blue-500",
      inStock: true,
      deliveryTime: "1-2 weeks",
      warranty: "2 years",
    },
    "dead-lock-1": {
      id: "dead-lock-1",
      title: "Dead Lock",
      description:
        "High-grade corrosion-free dead locks for wooden and metal doors",
      longDescription:
        "Dead lock is used for both wooden and metal doors with a size of 160mm length of lock body. We provide you dead lock with 304 grade which makes it corrosion free. It comes with 70mm and 80mm cylinder with 2 side key and 1 side key and one side knob.",
      imageSrc: "/Images/deadlock.jpg",
      additionalImages: [],
      price: 3500,
      rating: 4.6,
      reviews: 19,
      features: [
        "304 grade stainless steel construction",
        "Corrosion-free design",
        "160mm lock body length",
        "70mm and 80mm cylinder options",
        "2 side key, 1 side key, and one side knob options",
        "Compatible with wooden and metal doors",
      ],
      specifications: {
        Material: "304 grade stainless steel",
        "Lock Body Length": "160mm",
        "Cylinder Size": "70mm or 80mm",
        "Key Options": "2 side key, 1 side key, one side knob",
        Compatibility: "Wooden and metal doors",
        "Corrosion Resistance": "High",
      },
      category: "hardware",
      badge: "Security Hardware",
      badgeColor: "bg-blue-500",
      inStock: true,
      deliveryTime: "1 week",
      warranty: "3 years",
    },
    "d-handle-1": {
      id: "d-handle-1",
      title: "D Handle",
      description:
        "Heavy-duty stainless steel D handles for fire doors and metal doors",
      longDescription:
        "D handle is used on fire doors and on any other kind of metal doors for making easy access of doors by using handle to pull or push the doors. Our D handle comes with 304 grade & 202 grade with heavy duty steel so to make it fire rated its comes in different sizes as to meet customer requirement.",
      imageSrc: "/Images/D-Handle.png",
      additionalImages: [],
      price: 2000,
      rating: 4.4,
      reviews: 16,
      features: [
        "304 & 202 grade stainless steel options",
        "Heavy-duty construction",
        "Fire rated design",
        "Multiple size options",
        "Easy installation",
        "Compatible with fire doors and metal doors",
      ],
      specifications: {
        Material: "304 or 202 grade stainless steel",
        Construction: "Heavy-duty steel",
        "Fire Rating": "Up to 120 minutes",
        Sizes: "Multiple options available",
        Finish: "Polished stainless steel",
        Compatibility: "Fire doors and metal doors",
      },
      category: "hardware",
      badge: "Door Hardware",
      badgeColor: "bg-blue-500",
      inStock: true,
      deliveryTime: "1 week",
      warranty: "5 years",
    },
    "ss-hinges-1": {
      id: "ss-hinges-1",
      title: "SS Ball Bearing Hinges",
      description:
        "Fire rated stainless steel ball bearing hinges for heavy-duty applications",
      longDescription:
        "SS Ball bearing hinges are used in fire rated doors and in metal door and also in wooden fire rated and heavy duty doors. They come with a size of 4*3*3mm which is 2 hour fire rated and high durable product (304 grade).",
      imageSrc: "/Images/SS-Ball-Bearing-Hinges.png",
      additionalImages: [],
      price: 1800,
      rating: 4.7,
      reviews: 21,
      features: [
        "304 grade stainless steel",
        "Ball bearing mechanism for smooth operation",
        "4*3*3mm size",
        "2 hour fire rated",
        "High durability",
        "Compatible with fire rated doors, metal doors, and wooden doors",
      ],
      specifications: {
        Material: "304 grade stainless steel",
        Size: "4*3*3mm",
        Type: "Ball bearing",
        "Fire Rating": "2 hours",
        Durability: "High",
        Compatibility: "Fire rated doors, metal doors, wooden doors",
      },
      category: "hardware",
      badge: "Door Hardware",
      badgeColor: "bg-blue-500",
      inStock: true,
      deliveryTime: "1 week",
      warranty: "5 years",
    },
    "mortise-lock-1": {
      id: "mortise-lock-1",
      title: "Mortise & Sash Lock",
      description: "Combination latch and deadlock for secure door operation",
      longDescription:
        "Mortise lock is combination of latch and deadlock. They are used to open and close the doors and can also be locked with key from both side. The latch can be operated by a door knob or a handle. The only difference between sash lock and mortise lock is that mortise lock plate has a provision for cylinder whereas sash lock does not have provision of cylinder in its plate.",
      imageSrc: "/Images/Mortise&Sash-Lock.png",
      additionalImages: [""],
      price: 4500,
      rating: 4.6,
      reviews: 18,
      features: [
        "Combination of latch and deadlock",
        "Key operation from both sides",
        "Compatible with door knob or handle",
        "Mortise lock has cylinder provision",
        "Sash lock without cylinder provision",
        "Secure locking mechanism",
      ],
      specifications: {
        Type: "Mortise or Sash",
        Material: "Stainless steel",
        Operation: "Latch and deadlock combination",
        "Key Access": "Both sides",
        "Handle Compatibility": "Door knob or lever handle",
        Cylinder: "Mortise lock has provision, Sash lock does not",
      },
      category: "hardware",
      badge: "Security Hardware",
      badgeColor: "bg-blue-500",
      inStock: true,
      deliveryTime: "1-2 weeks",
      warranty: "3 years",
    },
    "fire-glass-1": {
      id: "fire-glass-1",
      title: "Fire Rated Glass",
      description:
        "Specially laminated glass that withstands high heat and prevents fire spread",
      longDescription:
        "Fire resistant glass is a specially laminated glass that helps the product withstand high amounts of heat. As a result, they can prevent fire from spreading from one side of the glass to another.",
      imageSrc: "/Images/fire-rated-glass.jpeg",
      additionalImages: [],
      price: 8000,
      rating: 4.8,
      reviews: 14,
      features: [
        "Specially laminated construction",
        "Withstands high heat",
        "Prevents fire spread",
        "Maintains visibility during fire",
        "Various sizes available",
        "Compatible with fire rated doors and windows",
      ],
      specifications: {
        Type: "Laminated fire resistant glass",
        "Fire Rating": "Up to 120 minutes",
        Thickness: "Various options available",
        Visibility: "Clear",
        "Heat Resistance": "High",
        Compatibility: "Fire rated doors and windows",
      },
      category: "accessories",
      badge: "Fire Resistant",
      badgeColor: "bg-red-500",
      inStock: true,
      deliveryTime: "2-3 weeks",
      warranty: "5 years",
    },
    "flush-bolt-1": {
      id: "flush-bolt-1",
      title: "Flush Bolt",
      description:
        "Secure the inactive leaf of door pairs with these quality flush bolts",
      longDescription:
        "Flush bolts are used to secure the inactive leaf of a pair of doors, projecting into the frame head and into a door strike. In this application, the active leaf would typically have a lockset which latches into a strike mounted on the edge of the inactive leaf.",
      imageSrc: "/Images/Flush-Bolt.png",
      additionalImages: [],
      price: 1500,
      rating: 4.5,
      reviews: 17,
      features: [
        "Secures inactive door leaf",
        "Projects into frame head and door strike",
        "Stainless steel construction",
        "Easy operation",
        "Compatible with double door setups",
        "Various sizes available",
      ],
      specifications: {
        Material: "Stainless steel",
        Application: "Inactive leaf of door pairs",
        Operation: "Manual",
        Projection: "Into frame head and door strike",
        Compatibility: "Double door setups",
        Sizes: "Various options available",
      },
      category: "hardware",
      badge: "Door Hardware",
      badgeColor: "bg-blue-500",
      inStock: true,
      deliveryTime: "1 week",
      warranty: "3 years",
    },
    "tower-bolt-1": {
      id: "tower-bolt-1",
      title: "Tower Bolt",
      description:
        "Simple and popular basic door security device made of stainless steel",
      longDescription:
        "Tower Bolt is simple and popular basic door security device. Standard straight tower bolt. The bolt is slid into the staple and the finger knob is rotated to engage in the housing slot thus locking it in position. Our Tower Bolt is made of stainless steel.",
      imageSrc: "/Images/Tower-Bolt.png",
      additionalImages: [],
      price: 1200,
      rating: 4.3,
      reviews: 20,
      features: [
        "Stainless steel construction",
        "Standard straight design",
        "Slide and rotate locking mechanism",
        "Basic door security",
        "Easy installation",
        "Various sizes available",
      ],
      specifications: {
        Material: "Stainless steel",
        Type: "Standard straight tower bolt",
        Operation: "Slide and rotate",
        "Security Level": "Basic",
        Installation: "Surface mounted",
        Sizes: "Various options available",
      },
      category: "hardware",
      badge: "Door Hardware",
      badgeColor: "bg-blue-500",
      inStock: true,
      deliveryTime: "1 week",
      warranty: "2 years",
    },
  };

  return products[id as keyof typeof products] || null;
};

export default async function ProductPage({
  params,
}: {
  params: { id: string };
}) {
  const product = await getProductData(params.id);

  if (!product) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center">
        <h1 className="text-2xl font-bold">Product not found</h1>
        <Button asChild className="mt-4">
          <Link href="/products">Back to Products</Link>
        </Button>
      </div>
    );
  }

  const categoryColors = {
    "fire-door": "text-fire-red-600",
    "anti-bacterial": "text-eco-green-600",
    security: "text-security-blue-600",
    hardware: "text-sky-blue-600",
    accessories: "text-warm-orange-600",
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6">
          <div className="mb-8">
            <Link
              href="/products"
              className="inline-flex items-center text-sm font-medium text-primary hover:underline"
            >
              <ArrowLeft className="mr-1 h-4 w-4" />
              Back to Products
            </Link>
          </div>

          <div className="grid gap-8 md:grid-cols-2">
            <div className="space-y-4">
              <div className="overflow-hidden rounded-lg border bg-white">
                <Image
                  src={product.imageSrc || "/placeholder.svg"}
                  alt={product.title}
                  width={700}
                  height={500}
                  className="w-full object-cover transition-transform hover:scale-105"
                />
              </div>
              <div className="grid grid-cols-3 gap-2">
                {product.additionalImages.map((img, i) => (
                  <div
                    key={i}
                    className="overflow-hidden rounded-md border bg-white cursor-pointer"
                  >
                    <Image
                      src={img || "/placeholder.svg"}
                      alt={`${product.title} view ${i + 1}`}
                      width={300}
                      height={300}
                      className="w-full h-24 object-cover transition-transform hover:scale-110"
                    />
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <Badge className={`${product.badgeColor} text-white`}>
                  {product.badge}
                </Badge>
                <h1 className="mt-2 text-3xl font-bold">{product.title}</h1>
                <div className="mt-2 flex items-center">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-5 w-5 ${
                          i < Math.floor(product.rating)
                            ? "fill-yellow-400 text-yellow-400"
                            : i < product.rating
                            ? "fill-yellow-400/50 text-yellow-400"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="ml-2 text-sm text-gray-600">
                    {product.rating.toFixed(1)} ({product.reviews} reviews)
                  </span>
                </div>
              </div>

              <div>
                <p className="text-4xl font-bold">
                  ₹{product.price.toLocaleString()}
                </p>
                <p className="text-sm text-gray-500">
                  Price includes GST & installation
                </p>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium">Description:</h3>
                <p className="text-gray-600">{product.longDescription}</p>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium">Key Features:</h3>
                <ul className="grid gap-1.5">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <CheckCircle
                        className={`h-4 w-4 ${
                          categoryColors[
                            product.category as keyof typeof categoryColors
                          ]
                        }`}
                      />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-1">
                  <div
                    className={`h-3 w-3 rounded-full ${
                      product.inStock ? "bg-green-500" : "bg-red-500"
                    }`}
                  ></div>
                  <span>{product.inStock ? "In Stock" : "Out of Stock"}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Truck className="h-4 w-4 text-gray-500" />
                  <span>Delivery: {product.deliveryTime}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Shield className="h-4 w-4 text-gray-500" />
                  <span>Warranty: {product.warranty}</span>
                </div>
              </div>

              <div className="flex gap-4">
                <Link href="/contact">
                  <Button
                    size="lg"
                    className="w-full interactive-button bg-gradient-professional text-white hover:shadow-lg"
                  >
                    Request Quote
                  </Button>
                </Link>
                <a href="/Devrath Comapany.pdf" download="Devrath Comapany.pdf">
                  <Button
                    size="lg"
                    variant="outline"
                    className="interactive-button border-sky-blue-300 text-sky-blue-700 hover:bg-sky-blue-50 dark:border-sky-blue-700 dark:text-sky-blue-400 dark:hover:bg-dark-blue-800"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Brochure
                  </Button>
                </a>
              </div>
            </div>
          </div>

          <Tabs defaultValue="specifications" className="mt-12">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="specifications">Specifications</TabsTrigger>
              <TabsTrigger value="installation">Installation</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>
            <TabsContent value="specifications" className="mt-6">
              <div className="rounded-lg border bg-card">
                <div className="grid divide-y">
                  {Object.entries(product.specifications).map(
                    ([key, value]) => (
                      <div key={key} className="grid grid-cols-2 p-4">
                        <div className="font-medium">{key}</div>
                        <div>{value}</div>
                      </div>
                    )
                  )}
                </div>
              </div>
            </TabsContent>
            <TabsContent value="installation" className="mt-6">
              <div className="rounded-lg border bg-card p-6 space-y-4">
                <h3 className="text-lg font-medium">Installation Guidelines</h3>
                <p>
                  Our professional installation team will handle the complete
                  installation process. Here's what to expect:
                </p>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>Site assessment and measurement verification</li>
                  <li>Preparation of the door opening</li>
                  <li>Frame installation and anchoring</li>
                  <li>Door hanging and hardware installation</li>
                  <li>Sealing and finishing</li>
                  <li>Testing and quality check</li>
                </ol>
                <div className="bg-blue-50 p-4 rounded-md border border-blue-100">
                  <h4 className="font-medium text-blue-800">Important Note</h4>
                  <p className="text-blue-700 text-sm">
                    For optimal performance, our doors must be installed by
                    certified technicians. DIY installation will void the
                    warranty.
                  </p>
                </div>
                <div className="mt-4">
                  <h4 className="font-medium">Maintenance Requirements</h4>
                  <p className="text-sm text-gray-600">
                    Regular maintenance is essential to ensure the longevity and
                    proper functioning of your door. We recommend:
                  </p>
                  <ul className="mt-2 space-y-1 text-sm">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>
                        Quarterly inspection of hinges and locking mechanisms
                      </span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Biannual lubrication of moving parts</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>
                        Annual professional inspection and certification
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="reviews" className="mt-6">
              <div className="rounded-lg border bg-card p-6 space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">Customer Reviews</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-sky-blue-300 text-sky-blue-700 hover:bg-sky-blue-50 dark:border-sky-blue-700 dark:text-sky-blue-400 dark:hover:bg-dark-blue-800"
                  >
                    Write a Review
                  </Button>
                </div>

                <div className="space-y-4">
                  <div className="border-b pb-4">
                    <div className="flex justify-between items-center mb-2">
                      <div className="font-medium">Dr. Rajesh Sharma</div>
                      <div className="text-sm text-gray-500">2 months ago</div>
                    </div>
                    <div className="flex mb-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`h-4 w-4 ${
                            star <= 5
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-gray-600">
                      Excellent quality product that perfectly meets our
                      requirements. The installation was professional and the
                      team was knowledgeable. Highly recommended for facilities
                      requiring high security and safety standards.
                    </p>
                  </div>

                  <div className="border-b pb-4">
                    <div className="flex justify-between items-center mb-2">
                      <div className="font-medium">Maj. Vikram Singh</div>
                      <div className="text-sm text-gray-500">3 months ago</div>
                    </div>
                    <div className="flex mb-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`h-4 w-4 ${
                            star <= 4
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-gray-600">
                      The security features are impressive. We've installed
                      these in our facility and they've performed exceptionally
                      well during security audits. The only improvement could be
                      in the delivery time.
                    </p>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <div className="font-medium">Dr. Priya Mehta</div>
                      <div className="text-sm text-gray-500">1 month ago</div>
                    </div>
                    <div className="flex mb-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`h-4 w-4 ${
                            star <= 5
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-gray-600">
                      The quality and durability of this product have been
                      crucial for our environment. We've seen a significant
                      improvement in security and safety since installation.
                      Customer service was also excellent throughout the
                      process.
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <section className="mt-16">
            <h2 className="text-2xl font-bold mb-6">Related Products</h2>
            <div className="grid gap-6 md:grid-cols-3">
              {Object.values(
                getProductData("metal-fire-door-1")
                  ? {
                      "wooden-fire-door-1":
                        getProductData("wooden-fire-door-1"),
                      "panic-bar-1": getProductData("panic-bar-1"),
                    }
                  : getProductData("wooden-fire-door-1")
                  ? {
                      "metal-fire-door-1": getProductData("metal-fire-door-1"),
                      "door-closer-1": getProductData("door-closer-1"),
                    }
                  : {
                      "metal-fire-door-1": getProductData("metal-fire-door-1"),
                      "wooden-fire-door-1":
                        getProductData("wooden-fire-door-1"),
                    }
              ).map(
                (relatedProduct) =>
                  relatedProduct && (
                    <div
                      key={relatedProduct.id}
                      className="group relative overflow-hidden rounded-lg border"
                    >
                      <Link
                        href={`/products/${relatedProduct.id}`}
                        className="absolute inset-0 z-10"
                      >
                        <span className="sr-only">View product</span>
                      </Link>
                      <div className="aspect-square overflow-hidden">
                        <Image
                          src={relatedProduct.imageSrc || "/placeholder.svg"}
                          alt={relatedProduct.title}
                          width={300}
                          height={300}
                          className="h-full w-full object-cover transition-transform group-hover:scale-105"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="font-medium">{relatedProduct.title}</h3>
                        <p className="mt-1 text-sm text-gray-500">
                          {relatedProduct.description}
                        </p>
                        <p className="mt-2 font-bold">
                          ₹{relatedProduct.price.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  )
              )}
            </div>
          </section>
        </div>
      </main>

      <Footer />
    </div>
  );
}
